Blender Importer for Ninja Ripper data
======================================

Imports meshes obtained via Ninja Ripper 1.5, with features for filtering redundant copies.
